--- This view shows the products purchased by only female customers

CREATE VIEW FemaleCustomers
AS
SELECT CUSTOMER.Customer_ID, CUSTOMER.First_Name, CUSTOMER.Last_Name, ORDER_LINE.Product_ID, PRODUCT.Product_Name
FROM CUSTOMER
INNER JOIN [ORDER]
ON CUSTOMER.Customer_ID = [ORDER].Customer_ID
INNER JOIN ORDER_LINE
ON [ORDER].Order_ID = ORDER_LINE.[Order_ID]
INNER JOIN PRODUCT
ON ORDER_LINE.Product_ID = PRODUCT.Product_ID
WHERE CUSTOMER.Gender = 'Female'
WITH CHECK OPTION;




