--- Returns the highest CM product for each vendor. Input Product Name to execute stored procedure 

CREATE PROCEDURE Max_CM (@Product_Name NVARCHAR(100))
AS 
BEGIN
SELECT (PRODUCT.Selling_Price-PRODUCT.Wholesale_Price) AS 'CM', PRODUCT.Vendor_ID, PRODUCT.Product_Name
FROM VENDOR
INNER JOIN PRODUCT
ON PRODUCT.Vendor_ID = VENDOR.Vendor_ID
WHERE Product_Name = @Product_Name AND (PRODUCT.Selling_Price-PRODUCT.Wholesale_Price) =
		(SELECT MAX(PRODUCT.Selling_Price-PRODUCT.Wholesale_Price) 
		FROM PRODUCT 
		WHERE PRODUCT.Vendor_ID = VENDOR.Vendor_ID)
ORDER BY (PRODUCT.Selling_Price-PRODUCT.Wholesale_Price ) DESC 

END;






