-- Skateboards database developed and written by Taravat Alipoor
-- Originally Written: October 13th, 2022 | Updated: NA

IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'Skateboards')
	CREATE DATABASE SkateBoards
GO
USE SkateBoards

-- Alter the path so the script can find the CSV files

DECLARE
	@data_path NVARCHAR(256);
SELECT @data_path = 'C:\Users\tarav\OneDrive\Documents\Daniels college\Enterprise Information Managment\303_Boards\';

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DISCOUNT'
       )
	DROP TABLE DISCOUNT;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'ORDER_LINE'
       )
	DROP TABLE ORDER_LINE;

	IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'ORDER'
       )
	DROP TABLE [ORDER];

	IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'RETURN'
       )
	DROP TABLE [RETURN];

	IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'CUSTOMER'
       )
	DROP TABLE CUSTOMER;

	IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'PRODUCT'
       )
	DROP TABLE [PRODUCT];

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'VENDOR'
       )
	DROP TABLE VENDOR;

	IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'RETURN_REASON'
       )
	DROP TABLE RETURN_REASON;

	-- Create tables

CREATE TABLE RETURN_REASON
	(Return_Reason_ID			INT CONSTRAINT pk_reason PRIMARY KEY,
	Return_Description			NVARCHAR(150)
	);
--
CREATE TABLE VENDOR
	(Vendor_ID					INT CONSTRAINT pk_vendor PRIMARY KEY,
	Vendor_Name					NVARCHAR(100) NOT NULL,
	Phone_Number 				NVARCHAR(15)  NOT NULL,
	Vendor_Street_Address		NVARCHAR(100) NOT NULL,
	Vendor_Zipcode				NVARCHAR(15)  NOT NULL,
	Vendor_City					NVARCHAR(50)  NOT NULL,
	Vendor_State				NVARCHAR(50)  NOT NULL 
	);
--
CREATE TABLE PRODUCT
	(Product_ID			INT CONSTRAINT pk_product PRIMARY KEY,
	 Vendor_ID			INT CONSTRAINT fk_vendorproduct FOREIGN KEY (Vendor_ID) REFERENCES VENDOR(Vendor_ID),
	 Product_Name		NVARCHAR(150) NOT NULL,
	 Selling_Price		INT NOT NULL,
	 Wholesale_Price	INT NOT NULL
	);
--
CREATE TABLE CUSTOMER
	(Customer_ID		INT CONSTRAINT pk_customer PRIMARY KEY,
	First_Name			NVARCHAR(100) NOT NULL,
	Last_Name			NVARCHAR(100) NOT NULL,
	Phone_Number		NVARCHAR(15)  NOT NULL,
	Email				NVARCHAR(50)  NOT NULL,
	Gender				NVARCHAR(20)  NOT NULL,
	DOB					DATE		  NOT NULL
	);
--
CREATE TABLE [RETURN]
	(RETURN_ID					INT CONSTRAINT pk_return PRIMARY KEY,
	Customer_ID					INT CONSTRAINT fk_customerreturn FOREIGN KEY (Customer_ID) REFERENCES CUSTOMER(Customer_ID),
	Return_Street_Address		NVARCHAR(100) NOT NULL,
	Return_Zipcode				NVARCHAR(15) NOT NULL,
	Return_City					NVARCHAR(50) NOT NULL,
	Return_State				NVARCHAR(50) NOT NULL, 
	Return_Date					Date NOT NULL,
	Return_Reason_ID			INT CONSTRAINT fk_reasonreturn FOREIGN KEY (Return_Reason_ID) REFERENCES RETURN_REASON(Return_Reason_ID)
	);
--
CREATE TABLE [ORDER]
	(Order_ID					INT CONSTRAINT pk_order PRIMARY KEY,
	Customer_ID					INT CONSTRAINT fk_customerorder FOREIGN KEY (Customer_ID) REFERENCES CUSTOMER(Customer_ID),			
	ZipCode						NVARCHAR(15) NOT NULL,
	Order_Street_Address		NVARCHAR(254) NOT NULL,
	Order_City					NVARCHAR(50) NOT NULL,
	Order_State					NVARCHAR(50) NOT NULL,
	Order_Date					Date NOT NULL,
	Payment_Type				NVARCHAR(254) NOT NULL
	);
--
CREATE TABLE ORDER_LINE --- how do i make a composite key?
	(Order_ID				INT CONSTRAINT fk_orderl FOREIGN KEY (Order_ID) REFERENCES [ORDER](Order_ID),
	Product_ID				INT CONSTRAINT fk_productorderline FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
	Date_Time				DATE NOT NULL,
	Quantity_On_Hand		INT  NOT NULL,
	Quantity_Ordered		INT NOT NULL,
	CONSTRAINT pk_order_line PRIMARY KEY (Order_ID, Product_ID, Date_Time)

	);
--
CREATE TABLE DISCOUNT
	(Discount_Code		INT CONSTRAINT pk_discount PRIMARY KEY,
	ORDER_ID			INT CONSTRAINT fk_orderdiscount FOREIGN KEY (ORDER_ID) REFERENCES [ORDER](ORDER_ID),
	Discount_Type		NVARCHAR(254) NOT NULL,
	[Start_Date]		DATE  NOT NULL,
	[End_Date]			DATE NOT NULL
	);


--

--- Below The Code Below Loads the Data Into My Database

	EXECUTE (N'BULK INSERT CUSTOMER FROM ''' + @data_path + N'CUSTOMER.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
---
EXECUTE (N'BULK INSERT VENDOR FROM ''' + @data_path + N'Vendor.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');

EXECUTE (N'BULK INSERT PRODUCT FROM ''' + @data_path + N'PRODUCT.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT [ORDER] FROM ''' + @data_path + N'ORDER.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT DISCOUNT FROM ''' + @data_path + N'DISCOUNT.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT ORDER_LINE FROM ''' + @data_path + N'ORDER_LINE.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
---
EXECUTE (N'BULK INSERT RETURN_REASON FROM ''' + @data_path + N'RETURN_REASON.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
---
EXECUTE (N'BULK INSERT [RETURN] FROM ''' + @data_path + N'RETURN.txt''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--





