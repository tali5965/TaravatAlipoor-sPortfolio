--- This function consists of inputing the numeric month like january = 1 
--- to find the total monthly sales for that month

CREATE FUNCTION ufn_TotalMonthlySales
	(@inputMonth DATETIME)
	
	RETURNS INT
BEGIN
	DECLARE @Sales INT 
	SELECT @Sales =  SUM(PRODUCT.Selling_Price*ORDER_LINE.Quantity_Ordered)
	FROM PRODUCT
		INNER JOIN ORDER_LINE
		ON PRODUCT.Product_ID = ORDER_LINE.Product_ID
	WHERE	@inputMonth = MONTH(ORDER_LINE.Date_Time)	
RETURN
	@Sales 
END;

